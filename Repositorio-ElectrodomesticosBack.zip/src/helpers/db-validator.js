import User from '../users/user.model.js'
import Role from '../role/role.model.js';
import MateriaPrima from "../materiaPrima/materiaPrima.model.js"; 
import ProductoTerminado from "../productoTerminado/productoTerminado.model.js";

export const validRole = async(role = '') => {
    if (role === "") return;  

    const existRole = await Role.findOne({ role });
    if (!existRole) {
        throw new Error(`Rol ${role} does not exist in the database`);
    }
}

export const existentEmail = async(email = '')=>{
    const existEmail = await User.findOne({email});
    if (existEmail) {
        throw new Error (`Email ${email} already exists in the database`)
    }
}

export const existUserById = async(id = ``)=>{
    const existUser = await User.findById(id);
    if (!existUser) {
        throw new Error(`ID  ${id} does not exist in the database`)
    }
}


export const existUsername = async(username = '') => {
    const existUsername = await User.findOne({username});
    if(existUsername){
        throw new Error(`Username ${username} already use`)
    }
}

export const userExistsById = async (id) => {
    const exist = await User.findById(id);
    if (!exist || !exist.status) {
        throw new Error(`User with ID ${id} does not exist in DB`);
    }
};

// Validaciones de Materia Prima
export const materiaPrimaExistsById = async (id) => {
    const exist = await MateriaPrima.findById(id);
    if (!exist || !exist.status) {
        throw new Error(`Materia Prima with ID ${id} does not exist in DB`);
    }
};

// Validaciones de Producto Terminado
export const productoTerminadoExistsById = async (id) => {
    const exist = await ProductoTerminado.findById(id);
    if (!exist || !exist.status) {
        throw new Error(`Producto Terminado with ID ${id} does not exist in DB`);
    }
};