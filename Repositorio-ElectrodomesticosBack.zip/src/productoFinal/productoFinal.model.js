import { Schema, model } from "mongoose";

const MaterialUsadoSchema = new Schema(
    {
        materiaPrima: {
            type: Schema.Types.ObjectId,
            ref: "MateriaPrima",
            required: true
        },
        cantidad: {
            type: Number,
            required: true,
            min: [1, "La cantidad debe ser al menos 1"]
        }
    },
    { _id: false }
);

// Solicitud de materiales para armar un producto final.
// Al crearla se descuenta el stock de cada materia prima usada.
const ProductoFinalSchema = new Schema(
    {
        // Producto que se está armando (opcional)
        productoTerminado: {
            type: Schema.Types.ObjectId,
            ref: "ProductoTerminado"
        },
        materiales: {
            type: [MaterialUsadoSchema],
            validate: [(v) => v.length > 0, "Debes indicar al menos una materia prima"]
        },
        // Usuario con sesión iniciada que hizo la solicitud
        solicitadoPor: {
            type: Schema.Types.ObjectId,
            ref: "User",
            required: true
        },
        status: {
            type: Boolean,
            default: true
        }
    },
    {
        timestamps: true,
        versionKey: false
    }
);

export default model("ProductoFinal", ProductoFinalSchema);
